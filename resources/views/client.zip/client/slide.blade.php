<!-- block slide top -->
<div class="block-slide-main slide-opt-1">

    <!-- slide -->
    <div class="owl-carousel dotsData"
        data-nav="true"
        data-dots="true"
        data-margin="0"
        data-items='1'
        data-autoplayTimeout="700"
        data-autoplay="true"
        data-loop="true">
        <div class="item item2" style="background-image: url(/client/images/media/index1/slide2.jpg);" data-dot="1">

            <div class="description">
                <span class="title">NEW COLLECTION </span>
                <span class="subtitle">BIG SALE</span>
                <span class="des"> ENJOY UP TO 35% OFF</span>
                <a href="" class="btn">SHOP NOW</a>
            </div>

        </div>

        <div class="item item1" style="background-image: url(/client/images/media/index1/slide1.jpg);" data-dot="2">

            <div class="description">
                <span class="title">We’ve Take A Further </span>
                <span class="subtitle">20% Off <br> Accessories</span>
                <a href="" class="btn">shop now</a>
            </div>

        </div>

        <div class="item item3" style="background-image: url(/client/images/media/index1/slide3.jpg);" data-dot="3">

            <div class="description">
                <span class="title">Spring Fashion  </span>
                <span class="subtitle">Fashion Colection Style 2016 </span>
                <a href="" class="btn">Now In Stock</a>
            </div>

        </div>
    </div> <!-- slide -->

</div><!-- block slide top -->

<!-- banner -->
<div class="banner-slide">
    <a href="" class="box-img"><img src="/client/images/media/index1/banner-slide1.jpg" alt="banner-slide"></a>
    <a href="" class="box-img"><img src="/client/images/media/index1/banner-slide2.jpg" alt="banner-slide"></a>
</div><!-- banner -->
